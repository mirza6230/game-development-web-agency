(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

var _burgerMenu = _interopRequireDefault(require("./components/burger-menu"));

var _popup = _interopRequireDefault(require("./components/popup"));

var _slider = _interopRequireDefault(require("./components/slider"));

var _select = _interopRequireDefault(require("./components/select"));

var _scrollTo = _interopRequireDefault(require("./components/scroll-to"));

var _mobHeight = _interopRequireDefault(require("./helpers/mob-height"));

var _bodyHeight = _interopRequireDefault(require("./helpers/body-height"));

var _fullPopup = _interopRequireDefault(require("./components/full-popup"));

var _tabs = _interopRequireDefault(require("./components/tabs"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

// You can write a call and import your functions in this file.
//
// This file will be compiled into app.js and will not be minified.
// Feel free with using ES6 here.
(function ($) {
  // When DOM is ready
  $(function () {
    _burgerMenu["default"].init();

    _popup["default"].init();

    (0, _slider["default"])();
    (0, _select["default"])();

    _scrollTo["default"].init();

    (0, _tabs["default"])();
    (0, _mobHeight["default"])();
    (0, _bodyHeight["default"])();
    var popups = new _fullPopup["default"](); //navigation

    if (document.querySelector('.js-menu')) {
      var lastId,
          topMenu = $('.js-menu'),
          menuItems = topMenu.find('a'),
          scrollItems = menuItems.map(function () {
        var item = $($(this).attr('href'));

        if (item.length) {
          return item;
        }
      });
      menuItems.click(function (e) {
        var href = $(this).attr('href'),
            offsetTop = href === '#' ? 0 : $(href).offset().top - 49;
        $('html, body').stop().animate({
          scrollTop: offsetTop
        }, 500);
        e.preventDefault();
      });
      $(window).scroll(function () {
        var fromTop = $(this).scrollTop() + 50;
        var cur = scrollItems.map(function () {
          if ($(this).offset().top < fromTop) return this;
        });
        cur = cur[cur.length - 1];
        var id = cur && cur.length ? cur[0].id : '';

        if (lastId !== id) {
          lastId = id;
          menuItems.parent().removeClass('active').end().filter("[href='#" + id + "']").parent().addClass('active');
        }
      });
    } // toggle site theme


    var themeSwitchers = document.querySelectorAll('.js-theme-switch');
    themeSwitchers.forEach(function (item) {
      return item.addEventListener('click', function (event) {
        var button = event.target.closest('button');
        if (!button || button.classList.contains('active')) return;
        var activeBtn = event.currentTarget.querySelector('.active');
        var isDark = button.classList.contains('js-theme-dark');
        activeBtn.classList.remove('active');
        button.classList.add('active');
        toggleTheme(isDark);
      });
    });

    function setTheme(themeName) {
      localStorage.setItem('theme', themeName);
      document.documentElement.className = themeName;
    }

    function toggleTheme(isDark) {
      if (isDark) {
        setTheme('theme-dark');
      } else {
        setTheme('theme-light');
      }
    }

    (function () {
      if (localStorage.getItem('theme') === 'theme-light') {
        setTheme('theme-light');
      } else {
        setTheme('theme-dark');
      }
    })(); //play btn


    var video = document.getElementById('video');
    var circlePlayButton = document.getElementById('play-btn');

    function togglePlay() {
      if (video.paused || video.ended) {
        video.play();
      } else {
        video.pause();
      }
    }

    circlePlayButton.addEventListener('click', togglePlay);
    video.addEventListener('playing', function () {
      circlePlayButton.style.opacity = 0;
    });
    video.addEventListener('pause', function () {
      circlePlayButton.style.opacity = 1;
    });
  });
})(jQuery);

},{"./components/burger-menu":2,"./components/full-popup":3,"./components/popup":4,"./components/scroll-to":5,"./components/select":6,"./components/slider":7,"./components/tabs":8,"./helpers/body-height":9,"./helpers/mob-height":10}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var BURGER = document.querySelector('.js-burger-open');
var NAV = document.querySelector('.js-burger');
var BODY = document.querySelector('body');
var CLASS_OVERFLOW = 'overflow';
var CLASS_ACTIVE = 'active';

var burgerMenu = function () {
  var burgeInit = function burgeInit() {
    if (!BURGER) return;
    BURGER.addEventListener('click', function (e) {
      if (!e.currentTarget.classList.contains('active')) {
        openBurger();
      } else {
        closeBurger();
      }
    });
  };

  var openBurger = function openBurger() {
    BURGER.classList.add(CLASS_ACTIVE);
    NAV.classList.add(CLASS_ACTIVE);
    BODY.classList.add(CLASS_OVERFLOW);
  };

  var closeBurger = function closeBurger() {
    BURGER.classList.remove(CLASS_ACTIVE);
    NAV.classList.remove(CLASS_ACTIVE);
    BODY.classList.remove(CLASS_OVERFLOW);
  };

  var init = function init() {
    burgeInit();
  };

  return {
    init: init,
    closeBurger: closeBurger
  };
}();

var _default = burgerMenu;
exports["default"] = _default;

},{}],3:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _bodyHeight = _interopRequireDefault(require("./../helpers/body-height"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var Popups = /*#__PURE__*/function () {
  function Popups() {
    var _this = this;

    _classCallCheck(this, Popups);

    _defineProperty(this, "POPUP_SHOW", document.querySelectorAll('[data-trigger]'));

    _defineProperty(this, "POPUPS_LIST", document.querySelectorAll('[data-popup]'));

    _defineProperty(this, "OVERLAY", document.querySelector('.js-overlay'));

    _defineProperty(this, "BODY", document.querySelector('body'));

    _defineProperty(this, "CLOSE_BTN", document.querySelectorAll('.js-popup-close'));

    _defineProperty(this, "SELECTOR_CLOSE", '.js-popup-close');

    _defineProperty(this, "SELECTOR_SHOW", '[data-trigger]');

    _defineProperty(this, "CLASS_ACTIVE", 'active');

    _defineProperty(this, "CLASS_OVERFLOW", 'overflow');

    _defineProperty(this, "handlers", function () {
      if (_this.POPUP_SHOW.length) {
        _this.POPUP_SHOW.forEach(function (opener) {
          opener.addEventListener('click', function (e) {
            e.preventDefault();
            var overlay = e.target.closest(_this.SELECTOR_SHOW).dataset.overlay;
            var trigger = e.target.closest(_this.SELECTOR_SHOW).dataset.trigger;

            _this.showPopup(trigger, overlay);
          });
        });
      }

      if (_this.OVERLAY) {
        _this.OVERLAY.addEventListener('click', function (e) {
          e.target.classList.remove(_this.CLASS_ACTIVE);

          _this.POPUPS_LIST.forEach(function (popup) {
            popup.classList.remove(_this.CLASS_ACTIVE);
          });

          _this.BODY.classList.remove(_this.CLASS_OVERFLOW);
        });
      }

      if (_this.CLOSE_BTN.length) {
        _this.CLOSE_BTN.forEach(function (closure) {
          closure.addEventListener('click', function (e) {
            _this.hidePopup();
          });
        });
      }
    });

    _defineProperty(this, "hidePopup", function () {
      _this.POPUPS_LIST.forEach(function (popup) {
        popup.classList.remove(_this.CLASS_ACTIVE);
      });

      _this.BODY.classList.remove(_this.CLASS_OVERFLOW);

      if (_this.OVERLAY && _this.OVERLAY.classList.contains(_this.CLASS_ACTIVE)) {
        _this.OVERLAY.classList.remove(_this.CLASS_ACTIVE);
      }
    });

    _defineProperty(this, "showPopup", function (target, overlay) {
      var currentPopup = document.querySelector("[data-popup=\"".concat(target, "\"]"));

      _this.POPUPS_LIST.forEach(function (popup) {
        popup.classList.remove(_this.CLASS_ACTIVE);
      });

      currentPopup.classList.add(_this.CLASS_ACTIVE);

      _this.BODY.classList.add(_this.CLASS_OVERFLOW);

      if (overlay != null || overlay != undefined) {
        if (!overlay) {
          _this.showOberlay();
        } else {
          var media = +overlay;

          if (_this.BODY.scrollWidth >= media) {
            _this.showOberlay();
          }
        }
      }

      (0, _bodyHeight["default"])();
    });

    this.handlers();
  }

  _createClass(Popups, [{
    key: "showOberlay",
    value: function showOberlay() {
      if (this.OVERLAY && !this.OVERLAY.classList.contains(this.CLASS_ACTIVE)) {
        this.OVERLAY.classList.add(this.CLASS_ACTIVE);
      }
    }
  }]);

  return Popups;
}();

var _default = Popups;
exports["default"] = _default;

},{"./../helpers/body-height":9}],4:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var showPopupBtns = document.querySelectorAll('.js-show-popup');
var popups = document.querySelectorAll('.js-popup');
var body = document.body;
var overlay = document.querySelector('.js-overlay');
var CLASS_ACTIVE = 'active';
var CLASS_OVERFLOW = 'overflow';

var popupsFunc = function () {
  var showPopup = function showPopup(event) {
    var openBtn = event.target.closest('.js-show-popup');
    var activePopup = document.querySelector('.js-popup.active');
    var targetPopup = document.querySelector("[data-popup=".concat(openBtn.dataset.trigger, "]"));

    if (activePopup) {
      activePopup.classList.remove(CLASS_ACTIVE);
    }

    if (openBtn.dataset.tab) {
      targetPopup.querySelector("[data-tab=\"".concat(openBtn.dataset.tab, "\"]")).classList.add(CLASS_ACTIVE);
      targetPopup.querySelector("[data-content=\"".concat(openBtn.dataset.tab, "\"]")).classList.add(CLASS_ACTIVE);
    }

    targetPopup.classList.add(CLASS_ACTIVE);
    body.classList.add(CLASS_OVERFLOW);
    overlay.classList.add(CLASS_ACTIVE);
  };

  var hidePopup = function hidePopup(activePopup) {
    if (!activePopup) {
      return;
    }

    body.classList.remove(CLASS_OVERFLOW);
    overlay.classList.remove(CLASS_ACTIVE);
    activePopup.classList.remove(CLASS_ACTIVE);

    if (document.querySelector('.active[data-content]') && document.querySelector('.active[data-tab]')) {
      document.querySelector('.active[data-content]').classList.remove(CLASS_ACTIVE);
      document.querySelector('.active[data-tab]').classList.remove(CLASS_ACTIVE);
    }
  };

  var showPopupInit = function showPopupInit() {
    if (showPopupBtns.length) {
      showPopupBtns.forEach(function (opener) {
        opener.addEventListener('click', function (event) {
          showPopup(event);
        });
      });
    }

    if (overlay) {
      overlay.addEventListener('click', function () {
        hidePopup(document.querySelector('.js-popup.active'));
      });
    }

    if (popups.length) {
      popups.forEach(function (popup) {
        popup.addEventListener('click', function (event) {
          var closeBtn = event.target.closest('.js-popup-close');

          if (!closeBtn) {
            return;
          }

          hidePopup(popup);
        });
      });
    }
  };

  var init = function init() {
    if (popups.length) {
      showPopupInit();
    }
  };

  return {
    init: init
  };
}();

var _default = popupsFunc;
exports["default"] = _default;

},{}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
// const ACTIVE = 'active';
var NAV_LINKS = document.querySelectorAll('.js-link-to');

var scrollTo = function () {
  var initScroll = function initScroll() {
    if (!NAV_LINKS.length) return;
    NAV_LINKS.forEach(function (link) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        var href = e.currentTarget.getAttribute('href').substring(1);
        top(href);
      });
    });
  };

  var top = function top(id) {
    var scrollTarget = document.getElementById(id);
    if (!scrollTarget) return;
    var topOffset = 0;
    var fixHeader = document.querySelector('.js-fixed-header');

    if (fixHeader) {
      topOffset = fixHeader.offsetHeight;
    }

    var elementPosition = scrollTarget.getBoundingClientRect().top;
    var offsetPosition = elementPosition - topOffset;
    window.scrollBy({
      top: offsetPosition,
      behavior: 'smooth'
    });
  };

  var init = function init() {
    initScroll();
  };

  return {
    init: init,
    top: top
  };
}();

var _default = scrollTo;
exports["default"] = _default;

},{}],6:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var SELECT_SELECTOR = '.js-select';
var BTN_SELECTOR = '.js-select-btn';
var LIST_SELECTOR = '.js-select-list';
var OPTION_SELECTOR = '.js-select-option';
var CLASS_ACTIVE = 'active';
var SELECTS = document.querySelectorAll('.js-select');

var initSelects = function initSelects() {
  if (!SELECTS.length) return;

  function closeAllSelect() {
    var btnList = document.querySelectorAll(BTN_SELECTOR);
    var selectList = document.querySelectorAll(LIST_SELECTOR);
    btnList.forEach(function (el) {
      return el.classList.remove(CLASS_ACTIVE);
    });
    selectList.forEach(function (el) {
      return el.classList.remove(CLASS_ACTIVE);
    });
  }

  SELECTS.forEach(function (select) {
    var btn = select.querySelector(BTN_SELECTOR);
    var selectList = select.querySelector(LIST_SELECTOR);
    var optionList = selectList.querySelectorAll(OPTION_SELECTOR);
    btn.addEventListener('click', function (e) {
      var target = e.target.closest(BTN_SELECTOR);

      if (target.classList.contains(CLASS_ACTIVE)) {
        target.classList.remove(CLASS_ACTIVE);
        selectList.classList.remove(CLASS_ACTIVE);
      } else {
        closeAllSelect();
        target.classList.add(CLASS_ACTIVE);
        selectList.classList.add(CLASS_ACTIVE);
      }
    });
    selectList.addEventListener('click', function (e) {
      var target = e.target.closest(OPTION_SELECTOR);

      if (target) {
        var value = target.getAttribute('data-value');
        var content = target.innerHTML;
        optionList.forEach(function (option) {
          return option.classList.remove(CLASS_ACTIVE);
        });
        target.classList.add(CLASS_ACTIVE);
        btn.classList.remove(CLASS_ACTIVE);
        btn.innerHTML = content;
        btn.setAttribute('data-value', value);
        selectList.classList.remove(CLASS_ACTIVE);
      }
    });
  });
  document.addEventListener('click', function (e) {
    var target = e.target;

    if (target && !target.closest(SELECT_SELECTOR)) {
      closeAllSelect();
    }
  });
};

var _default = initSelects;
exports["default"] = _default;

},{}],7:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

function initSwiper() {
  //slider
  var projSlider = document.querySelector('.js-proj-slider');

  if (projSlider) {
    var slider1 = new Swiper('.js-proj-slider', {
      slidesPerView: 'auto',
      spaceBetween: 20,
      breakpoints: {
        768: {
          spaceBetween: -10
        },
        1024: {
          spaceBetween: 0
        },
        1920: {
          spaceBetween: 150
        }
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev'
      }
    });
  }

  var newsSlider = document.querySelector('.js-news-slider');

  if (newsSlider) {
    var slider2 = new Swiper('.js-news-slider', {
      slidesPerView: 1,
      spaceBetween: 0,
      loop: true,
      grid: {
        fill: 'column',
        rows: 2
      },
      breakpoints: {
        768: {
          spaceBetween: 30,
          slidesPerView: 1.6,
          slidesPerGroup: 1
        },
        1024: {
          spaceBetween: 40,
          slidesPerView: 2
        },
        1440: {
          spaceBetween: 80,
          slidesPerView: 2
        }
      }
    });
  }
}

var _default = initSwiper;
exports["default"] = _default;

},{}],8:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var CLASS_ACTIVE = 'active';
var wrapList = document.querySelectorAll('.js-tabs');

function initTabs() {
  if (!wrapList.length) return;
  wrapList.forEach(function (wrap) {
    return attachEvents(wrap);
  });

  function attachEvents(parent) {
    var tabList = parent.querySelectorAll('[data-tab]'),
        contentList = parent.querySelectorAll('[data-content]');
    if (!tabList.length) return;
    tabList.forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        tabList.forEach(function (btn) {
          return btn.classList.remove(CLASS_ACTIVE);
        });
        e.currentTarget.classList.add(CLASS_ACTIVE);
        var idContent = e.currentTarget.dataset.tab;

        if (idContent === 'all') {
          contentList.forEach(function (content) {
            return content.classList.add(CLASS_ACTIVE);
          });
        } else {
          var currentContentList = parent.querySelectorAll("[data-content=\"".concat(idContent, "\"]"));
          contentList.forEach(function (content) {
            return content.classList.remove(CLASS_ACTIVE);
          });
          currentContentList.forEach(function (content) {
            return content.classList.add(CLASS_ACTIVE);
          });
        }
      });
    });
  }
}

var _default = initTabs;
exports["default"] = _default;

},{}],9:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var WRAP_SELECTOR = '.js-wrap';
var HEAD_SELECTOR = '.js-head';
var BODY_SELECTOR = '.js-body';
var FOOTER_SELECTOR = '.js-footer';

var initBodyHeight = function initBodyHeight() {
  var wrapList = document.querySelectorAll(WRAP_SELECTOR);
  if (!wrapList.length) return;

  var initHeight = function initHeight(wrap) {
    var head = wrap.querySelector(HEAD_SELECTOR),
        body = wrap.querySelector(BODY_SELECTOR),
        footer = wrap.querySelector(FOOTER_SELECTOR),
        wrapHeight = +window.getComputedStyle(wrap).height.slice(0, -2) - +window.getComputedStyle(wrap).paddingBottom.slice(0, -2);
    var outherHead = 0;

    if (head) {
      outherHead += head.scrollHeight;
    }

    if (footer) {
      outherHead += footer.scrollHeight;
    }

    if (outherHead && body) {
      body.style.height = wrapHeight - outherHead + 'px';
      body.style.overflow = 'hidden';
      body.style.overflowY = 'auto';
    }
  };

  wrapList.forEach(function (wrap) {
    initHeight(wrap);
  });
  window.addEventListener('resize', function () {
    wrapList.forEach(function (wrap) {
      initHeight(wrap);
    });
  });
};

var _default = initBodyHeight;
exports["default"] = _default;

},{}],10:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

//window height
var mobHeight = function mobHeight() {
  var vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', "".concat(vh, "px"));
  window.addEventListener('resize', function () {
    var vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', "".concat(vh, "px"));
  });
};

var _default = mobHeight;
exports["default"] = _default;

},{}]},{},[1]);
